#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    constexpr int HEIGHT_CATEGORY1 = 1;
    constexpr int HEIGHT_CATEGORY2 = 2;
    constexpr int HEIGHT_CATEGORY3 = 3;

    constexpr double PRICE1 = 50.00;   // price for tree < 1 m tall		-- HEIGHT_CATEGORY1
    constexpr double PRICE2 = 109.00;  // price for tree [1, 2[ m tall	-- HEIGHT_CATEGORY2
    constexpr double PRICE3 = 199.00;  // price for tree [2, 3[ m tall	-- HEIGHT_CATEGORY3
    constexpr double PRICE4 = 299.50;  // price for tree >= 3m tall

    constexpr double PRICE_PER_TREE_DELIVERY = 120.00;
    constexpr double MAX_DELIVERY = 600.00;

    int n_trees = 0;      // number of trees bought
    double height = 0.0;  // Tree height
    int extra_service_option = -1;  // whether trees are not delivered (0), delivered (1), planted (2)

    double tree_cost = 0.0;        // cost per tree

    // 1. Get purchase information and validate
    bool invalid_input = false;

    do {
        // Read number of trees
        cout << "Number of trees purchased: ";
        cin >> n_trees;

        // Read tree height
        cout << "Tree height: ";
        cin >> height;

        // Read extra service option
        cout << "Extra services (0 -> none, 1 -> delivery, 2 -> planting): ";
        cin >> extra_service_option;

        // Test whether the input is valid
        invalid_input =
            (n_trees < 0 || height <= 0.0 || extra_service_option < 0 || extra_service_option > 2);

        if (invalid_input) {
            cout << "Purchase information not valid!!" << endl << endl;
        }
    } while (invalid_input);

    // 2. Calculate the tree costs

    // Compute price per tree based on the given height
    if (height < HEIGHT_CATEGORY1) {
        tree_cost = PRICE1;
    } else if (height < HEIGHT_CATEGORY2) {
        tree_cost = PRICE2;
    } else if (height < HEIGHT_CATEGORY3) {
        tree_cost = PRICE3;
    } else {
        tree_cost = PRICE4;
    }

    // Calculate total price for all trees
    double total_tree_cost = tree_cost * n_trees;

    double delivery_cost = 0.0;    // delivery cost for all trees
    double planting_cost = 0.0;    // planting cost for all trees

    // Calculate extra service costs
    switch (extra_service_option) {
        case 0:
            break;  // no extra services

        case 1:  // delivery service
            if (n_trees < MAX_DELIVERY / PRICE_PER_TREE_DELIVERY) {
                delivery_cost = PRICE_PER_TREE_DELIVERY * n_trees;
            } else {
                delivery_cost = MAX_DELIVERY;
            }
            break;

        case 2:  // delivery+planting service
            planting_cost = total_tree_cost / 2;
            break;

        default: ;  // should never get here
    }

    // Calculate total invoice amount
    double total_cost = total_tree_cost + delivery_cost + planting_cost;

    // 3. Display invoice
    cout << fixed << setprecision(2);

    cout << endl << "=================================" << endl;
    cout << setw(20) << "Invoice" << endl;
    cout << "=================================" << endl;

    cout << setw(6) << n_trees << " trees"
         << " * " << tree_cost << " each: " << setw(10) << total_tree_cost << endl;

    cout << setw(27) << "Delivery charge: " << setw(10) << delivery_cost << endl;
    cout << setw(27) << "Planting charge: " << setw(10) << planting_cost << endl;
    cout << setw(37) << "---------" << endl;
    cout << setw(26) << "Total amount due: " << setw(10) << total_cost << endl;

    return 0;
}
