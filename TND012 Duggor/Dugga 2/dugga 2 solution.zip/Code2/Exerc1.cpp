// ===============================================================
// TND012/2019, Dugga 2
// ===============================================================

/*
Test data 1:
Radius =  5
Length = 10

10 -2
3 9
7 6
2 -10
9 10
4 -5
5 22
3 -4
-3 -2
3 4
3 9
8 8
STOP
*/

/*
Test data 2:
Radius =  8
Length = 8

-1 -3
2 6
-5 8
-8 -7
2 2
0 6
8 7
-5 0
8 5
8 5
-2 -7
1 -8
-5 -2
7 -3
-1 -8
7 4
8 -3
6 -8
-7 -8
-1 3
20 -20
0 -3
2 -2
3 2
8 -8
STOP
*/

/*
Test data 3:
Radius: 12
Length: 6

22 50
-4 1
-3 0
1 1
6 -2
-6 5
0 0
5 -6
5 -1
-3 4
-1 2
-2 -4
2 -1
-4 4
0 0
-5 3
4 -1
STOP
*/

#include <iostream>
#include <iomanip>  //setprecision, fixed
#include <cstdlib>  //rand, srand
#include <cmath>    //sqrt

using namespace std;

//#define DEBUG

int main() {
    constexpr int MIN =
        5;  // min value for radius and half square side length
            // with less then 5 than one cannot guarantee that 100 different points can be generated

    int radius = 0;  // radius should be >5
    int length = 0;  // length should be >5

    bool invalid_input = false;

    // 1. Read and validate the radius and the length
    do {
        cout << "Radius: ";
        cin >> radius;

        cout << "Length: ";
        cin >> length;

        invalid_input = (radius < MIN) || (length < MIN);

        if (invalid_input) {
            cout << "Not valid input!!" << endl << endl;
        }
    } while (invalid_input);

    // 2. Read the points
    constexpr int SIZE = 100;  // max number of points that can stored by the program

    int X_coord[SIZE] = {0};  // to store the x-coordinate of the points
    int Y_coord[SIZE] = {0};  // to store the y-coordinate of the points
    int dist[SIZE] = {0};     // to store the square of the distance of each point to point (0,0)

    int howMany = 0;  // number of points

    int x = 0;
    int y = 0;

    cout << "Enter the points:" << endl;

    while (cin >> x && cin >> y) {

        if (x > length || x < -1 * length || y > length ||
            y < -1 * length)  // test point (x,y) is outside the square
            continue;

        // Test if point (x,y) has been read before
        bool found = false;

        for (int j = 0; j < howMany; ++j) {
            if (X_coord[j] == x && Y_coord[j] == y) {
                found = true;
                break;
            }
        }

        // if (found == false)
        if (!found)  //(x,y) is a new point
        {
            // Save the point coordinates in the X_ Y_ arrays
            X_coord[howMany] = x;
            Y_coord[howMany] = y;

            // Store the square distance of the point to the circle center (0,0) in array dist
            dist[howMany] = x * x + y * y;
            ++howMany;
        }

        // Test if all slots are occupied
        if (howMany == SIZE)
            break;  // stop the reading
    }

    cout << fixed << setprecision(2) << endl;

#ifdef DEBUG
    // Debug: display the points and their distances to point (0,0)
    cout << "Distances: " << endl;

    for (int i = 0; i < howMany; ++i) {
        cout << setw(4) << X_coord[i] << setw(4) << Y_coord[i] << setw(8) << sqrt(dist[i]);

        if ((i + 1) % 4 == 0)
            cout << endl;
    }

    cout << endl << endl;
#endif

    // 3. Display which points are in/out of the circle

    for (int i = 0; i < howMany; ++i) {
        cout << "(" << X_coord[i] << "," << Y_coord[i] << ")";

        // Test if point (x,y) is inside the circle
        if (dist[i] < radius * radius) {
            cout << " in the circle." << endl;
        } else {
            cout << " NOT in the circle." << endl;
        }
    }

    // 4. Sort the (square) distances
    // Algorithm of lesson 4, exercise 5
    for (int j = 0; j < howMany - 1; ++j) {
        int min = j;

        for (int i = j + 1; i < howMany; ++i) {
            if (dist[i] < dist[min]) {
                min = i;
            }
        }

        if (min != j)  // dist[min] < A[j]
        {
            // swap dist[j] with dist[min]
            int aux = dist[j];
            dist[j] = dist[min];
            dist[min] = aux;
        }
    }

#ifdef DEBUG
    // Debug: display the sorted distances
    cout << "\nSorted distances: " << endl;

    for (int i = 0; i < howMany; ++i) {
        cout << setw(8) << sqrt(dist[i]);

        if ((i + 1) % 4 == 0)
            cout << endl;
    }

    cout << endl;
#endif

    // 5. Display the median distance of the generated points
    cout << "\nMedian distance to point (0,0): ";

    double median = sqrt(dist[howMany / 2]);

    if (howMany % 2 == 0 && howMany > 0) { //avoid access outside array boundaries, if howMany is zero
            median = (median + sqrt(dist[howMany / 2 - 1])) / 2.0;
    }

    cout << median << endl;

    return 0;
}
