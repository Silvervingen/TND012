// ===============================================================
// TND012: 2019, Dugga 3
// ===============================================================

#include <iostream>
#include <iomanip>  //setw
#include <cmath>    //abs

using namespace std;

/*
Line L: 3 -3
Number of lines: 5
2.3 4
3 10
12 8.8
0 12
3 2.8
*/

/*
Line L: -3.5 -6.5
Number of lines: 6
1 1
-1 -1
1 -1
-1 1
0 6.6
0 -6.6
*/

/****************************************
 * Declaration of type Line and Point    *
 *****************************************/

struct Line  // a line is represented by the equation y = mx + b
{
    double m = 0.0;
    double b = 0.0;
};

struct Point {
    double x_coord = 0.0;
    double y_coord = 0.0;
};

/****************************************
 * Function declarations (prototypes)    *
 *****************************************/

// Read a line from cin
Line read_line();

void display_line(const Line& L);

void display_point(const Point& p);

bool is_parallel(const Line& a, const Line& b);

Point find_intersect_point(const Line& L1, const Line& L2);

/* ************************************ */

int read_numberOFlines(int ub);

// Read user given lines and store them in array V
// at most n lines can be stored in V
// Function returns number of lines read and stored in V
int read_lines(Line V[], int n);

void display_paralell_lines(const Line V[], int n, const Line& L);

void display_intersect_lines(const Line V[], int n, const Line& L);

/**************************
 * 3. MAIN                *
 **************************/

int main() {
    cout << "Enter a line L (m followed by b): ";
    Line L = read_line();

    constexpr int SIZE = 100;

    // Read lines and store them in an array
    Line theLines[SIZE];

    int howMany = read_lines(theLines, SIZE);

    cout << fixed << setprecision(2);

    cout << "\n\nLines parallel with line ";
    display_line(L);
    cout << endl;

    display_paralell_lines(theLines, howMany, L);

    cout << "\n\nLines that intersect with line ";
    display_line(L);
    cout << endl;

    display_intersect_lines(theLines, howMany, L);

    return 0;
}

/*************************************
 * Function definitions               *
 **************************************/

// Read a line from cin
Line read_line() {
    Line L;

    cin >> L.m >> L.b;

    return L;
}

void display_line(const Line& L) {
    cout << "y = " << L.m << 'x';

    if (L.b < 0.0) {
        cout << " - ";
    } else {
        cout << " + ";
    }

    cout << abs(L.b);
}

void display_point(const Point& p) {
    cout << "(" << p.x_coord << ", " << p.y_coord << ")";
}

bool is_parallel(const Line& a, const Line& b) {
    return (a.m == b.m);
}

Point find_intersect_point(const Line& L1, const Line& L2) {
    Point p;

    p.x_coord = (L2.b - L1.b) / (L1.m - L2.m);

    p.y_coord = L1.m * p.x_coord + L1.b;

    return p;
}

int read_numberOFlines(int ub) {
    bool valid = false;
    int n_lines = 0;

    do  // read number of lines and validate it
    {
        cout << "Enter number of lines: ";
        cin >> n_lines;

        valid = (n_lines >= 0 && n_lines <= ub);

        if (valid == false) {
            cout << "Invalid number of lines!!" << endl;
        }
    } while (valid == false);

    return n_lines;
}

// Read user given lines and store them in array V
// at most n lines can be stored in V
// Function returns number of lines read and stored in V
int read_lines(Line V[], int n) {
    int n_lines = read_numberOFlines(n);

    if (n_lines == 0)
        return n_lines;

    cout << "Enter " << n_lines << " lines:\n";

    // Read the lines
    for (int i = 0; i < n_lines; ++i) {
        V[i] = read_line();
    }

    return n_lines;
}

void display_paralell_lines(const Line V[], int n, const Line& L) {
    int counter = 0;

    for (int i = 0; i < n; i++) {
        if (is_parallel(V[i], L)) {

            counter++;

            display_line(V[i]);
            cout << endl;
        }
    }

    if (counter == 0) {
        cout << "No parallel lines found!!\n";
    }
}

void display_intersect_lines(const Line V[], int n, const Line& L) {
    int counter = 0;

    for (int i = 0; i < n; i++) {
        if (is_parallel(V[i], L) == false) {

            counter++;

            display_line(V[i]);
            cout << '\t';

            cout << "Intersection point: ";
            Point p = find_intersect_point(V[i], L);
            display_point(p);
            cout << endl;
        }
    }

    if (counter == 0) {
        cout << "No intersection lines found!!\n";
    }
}
